<footer class="bg-dark">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="m-auto">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active mr-5">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item mr-5">
                        <a class="nav-link" href="#">Produits</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="formulaire_contact.php">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <section class="container text-center pb-3 text-light mt-2">
        <h5>Site propulsé par Pierre, David, Julien, Stéphane et Thomas</h5>
    </section>
</footer>